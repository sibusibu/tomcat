package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
	@Autowired
	public CustomerRepository customerRepo;
	public void generateCustomer(Customer cust) {
		// TODO Auto-generated method stub
		customerRepo.save(cust);
	}
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerRepo.findAll();
	}
	public Customer getCustomerById(Long cId)
	{
		Optional<Customer> ocust=customerRepo.findById(cId);
		return ocust.get();
	}
	public void deleteCustomerById(Long cId) {
		customerRepo.deleteById(cId);
	}
	public void updateCustomerById(	Customer cu,Long cId) {
		Optional<Customer> cust=customerRepo.findById(cId);
		if(cust.isPresent())
		{
			cu.setCustomerId(cId);
			customerRepo.save(cu);
		}
		else
		{
			System.out.println("id is not found");
			
		}
		
	}
}
